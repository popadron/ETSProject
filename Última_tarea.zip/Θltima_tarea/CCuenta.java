public class CCuenta {

    private String nombre;
    private String cuenta;
    private double saldo;
    private double tipoInterés;

    public CCuenta()
    {
    }

    public CCuenta(String nom, String cue, double sal, double tipo)
    {
        nombre =nom;
        cuenta=cue;
        saldo=sal;
    }

    public double estado()
    {
        return saldo;
    }

    public void operativa_cuenta(CCuenta cuenta) {
    	float cantidad;
    	
    	try {
    		System.out.println("Tu saldo es de " + cuenta.estado());
            cuenta.retirar(2300);
            System.out.println("Tu saldo tras retirar: " + cuenta.estado());
        } catch (Exception e) {
            System.out.print("Fallo al retirar");
        }
        try {
        	System.out.println("Tu saldo es de " + cuenta.estado());
            System.out.println("Ingreso en cuenta");
            cuenta.ingresar(695.0);
            System.out.println("Tu saldo tras ingresar: " + cuenta.estado());
        } catch (Exception e) {
            System.out.print("Fallo al ingresar");
        }
    }
    
    public void ingresar(double cantidad) throws Exception
    {
        if (cantidad<0)
            throw new Exception("No se puede ingresar una cantidad negativa");
        saldo = saldo + cantidad;
    }

    public void retirar(double cantidad) throws Exception
    {
        if (cantidad <= 0)
            throw new Exception ("No se puede retirar una cantidad negativa");
        if (estado()< cantidad)
            throw new Exception ("No se hay suficiente saldo");
        saldo = saldo - cantidad;
    }

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getTipoInterés() {
		return tipoInterés;
	}

	public void setTipoInterés(double tipoInterés) {
		this.tipoInterés = tipoInterés;
	}
}
